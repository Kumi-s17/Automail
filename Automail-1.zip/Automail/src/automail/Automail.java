package automail;

import simulation.IMailDelivery;


/**
 * Changes made by
 * @author W07 Team 05 [Fri 10:00AM]
 */

/**
 * Automail System contains mailpool and robots
 * */
public class Automail {
	      
    public Robot[] robots;
    public MailPool mailPool;

    /**
	 * Initiates the robots based on the number of robots used in the simulation.
	 * The Robot behaviour is also set
	 *
	 * @param mailPool the mailpool the system is using
	 * @param delivery delivery report
	 * @param numRobots number of robots in the simulation
	 * */
    public Automail(MailPool mailPool, IMailDelivery delivery, int numRobots) {
    	/** Initialize the MailPool */
    	this.mailPool = mailPool;
    	
    	/** Initialize robots */
    	robots = new Robot[numRobots];

    	//if charge threshold value is 0 then set the behaviour of the robots to false(normal behaviour)
    	if (ChargeInformation.getInstance().getChargeThreshold() <= 0){
			for (int i = 0; i < numRobots; i++) {
				robots[i] = new Robot(delivery, mailPool, i, false);
			}
		}
		//if charge threshold value is > 0 then set the behaviour of the robots to true(charge tenants)
    	else if (ChargeInformation.getInstance().getChargeThreshold() > 0){
			for (int i = 0; i < numRobots; i++) {
				robots[i] = new Robot(delivery, mailPool, i, true);
			}
		}

    }


    
}
