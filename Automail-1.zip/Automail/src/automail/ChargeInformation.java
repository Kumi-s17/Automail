package automail;

import com.unimelb.swen30006.wifimodem.WifiModem;

/**
 * Created by
 * @author W07 Team 05 [Fri 10:00AM]
 */

/**
 * Holds all the information relating to charging tenant
 * */
public class ChargeInformation implements Chargeable{

    private static ChargeInformation charge = null;

    private double chargeThreshold;
    private double markupPercentage;
    private double activityUnitPrice;

    private Boolean chargeDisplay;
    private int failedLookUp = 0;

    public int getFailedLookUp() {
        return failedLookUp;
    }

    public static ChargeInformation getInstance(){
        if (charge == null){
            charge = new ChargeInformation();
        }
        return charge;
    }

    public double getChargeThreshold(){
        return this.chargeThreshold;
    }

    public void setChargeThreshold(double charge){
        this.chargeThreshold = charge;

    }

    public double getMarkupPercentage(){
        return this.markupPercentage;
    }

    public void setMarkupPercentage(double value){
        this.markupPercentage = value;
    }

    public double getActivityUnitPrice(){
        return this.activityUnitPrice;
    }

    public void setActivityUnitPrice(double value) {
        this.activityUnitPrice = value;
    }

    public Boolean getChargeDisplay(){
        return this.chargeDisplay;
    }

    public void setChargeDisplay(Boolean chargeDisplay){
        this.chargeDisplay = chargeDisplay;
    }

    /**
     * Calculates the charge the tenant is going to pay
     *
     * @param cost The cost the tenant is paying for
     * @return the amount that the tenant is being charged
     * */
    public double calculateCharge(double cost) throws Exception {
        //charge = cost * (1 + markupPercentage)

        double charge = cost * (1 + markupPercentage);
        return charge;
    }

    /**
     * Calculates the cost the tenant is going to pay based upon the serviceFee and Activity Units
     *
     * @param serviceFee service fee retrieved from the Wifi Modem
     * @param activityCost activity cost calculated for the mail item delivered
     * @return the cost the tenant is paying for
     * */
    public double calculateCost(double serviceFee, double activityCost) throws Exception {
        //cost = Service fee + Activity Cost
        double cost;

        cost = serviceFee + activityCost;

        return cost;
    }

    /**
     * Calculates the Activity units based on the destination floor
     *
     * @param destinationFloor the floor where the item is being delivered
     * @return activity units used to calculate the activity cost
     * */
    public double calculateActivityUnits(int destinationFloor){

        //Add activity unit from 1 successful lookup
        double activityUnits = LOOKUPACTIVITYUNIT ;

        //Add activity units from travelling between floors
        activityUnits += floorCost(destinationFloor);



        return activityUnits;
    }

    /**
     * Calculates the Activity Cost based on the work done by the robot
     *
     * @param activityUnits activity units used to calculate the activity cost
     * @return cost for all the activity done
     * */
    public double calculateActivityCost(double activityUnits){
        double activityCost;

        activityCost = activityUnits * activityUnitPrice;

        return activityCost;

    }

    /**
     * Retrieves the service fee from the Wifi Modem
     *
     * @param destinationFloor the floor where the item is being delivered
     * @return The service fee at the moment of time this function is called
     * */
    public double calculateServiceFee(int destinationFloor) throws Exception{
        WifiModem wifiModem = WifiModem.getInstance(1);
        double serviceFee = wifiModem.forwardCallToAPI_LookupPrice(destinationFloor);
        Statistics.getInstance().increaseNumOfLookUps();
        this.failedLookUp = 0;
        while (serviceFee == -1) {
            this.failedLookUp += 1;
            Statistics.getInstance().increaseFailedLookUps();
            serviceFee = wifiModem.forwardCallToAPI_LookupPrice(destinationFloor);
            Statistics.getInstance().increaseNumOfLookUps();
        }
        Statistics.getInstance().increaseSuccessfulLookUps();
        return serviceFee;
    }

    /**
     * Calculates the activity units that the robot is undertaking between the MailRoom location
     * and destination floor of the Mail item
     *
     * @param destinationFloor the floor where the item is being delivered
     * @return The activity units the robot is going to exhaust delivering the items
     * */
    public double floorCost(int destinationFloor){
        int startingFloor = 1;
        int diffBetweenFloors = destinationFloor - startingFloor;
        double units = diffBetweenFloors * 2 * 5;
        return units;
    }
}
