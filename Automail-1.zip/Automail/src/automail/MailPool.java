package automail;

import java.util.LinkedList;
import java.util.Comparator;
import java.util.ListIterator;

import exceptions.ItemTooHeavyException;

/**Changes made by
 * @author W07 Team 05 [Fri 10:00AM]
 */

/**
 * addToPool is called when there are mail items newly arrived at the building to add to the MailPool or
 * if a robot returns with some undelivered items - these are added back to the MailPool.
 * The data structure and algorithms used in the MailPool is your choice.
 * 
 */
public class MailPool {

	private class Item {
		
		int destination;
		MailItem mailItem;
		
		// Use stable sort to keep arrival time relative positions
		
		public Item(MailItem mailItem) {
			destination = mailItem.getDestFloor();
			this.mailItem = mailItem;
		}
	}

	/**
	 * Overrides existing compare with new compare
	 * New compare method compares the destination floor of two items
	 * */
	public class ItemComparator implements Comparator<Item> {
		@Override
		public int compare(Item i1, Item i2) {
			int order = 0;
			if (i1.destination < i2.destination) {
				order = 1;
			} else if (i1.destination > i2.destination) {
				order = -1;
			}
			return order;
		}
	}
	
	private LinkedList<Item> priorityPool;
	private LinkedList<Item> normalPool;
	private LinkedList<Robot> robots;


	/**
	 * Initiates the mail pools in the mail room
	 *
	 * @param nrobots number of robots used in the simulation
	 * */
	public MailPool(int nrobots){
		// Start empty
		normalPool = new LinkedList<Item>();
		priorityPool = new LinkedList<Item>();
		robots = new LinkedList<Robot>();
	}

	/**
     * Adds an item to the mail pool
	 *
     * @param mailItem the mail item being added.
     */
	public void addToPool(MailItem mailItem) {
		Item item = new Item(mailItem);
		normalPool.add(item);
		normalPool.sort(new ItemComparator());
	}

	/**
	 * Adds an item to the respective  mail pool depending on the charge threshold and expected charge of a mail item
	 *
	 * @param mailItem the mail item being added.
	 * @param chargeInformation the charge information class that hold all the methods and information relating to charging the tenant
	 */
	public void addToPool(MailItem mailItem, ChargeInformation chargeInformation) throws Exception {
		Item item = new Item(mailItem);
		int destination = item.mailItem.getDestFloor();

		double activityUnits = chargeInformation.calculateActivityUnits(destination);
		double expectedActivityCost = chargeInformation.calculateActivityCost(activityUnits);
		double expectedServiceFee = chargeInformation.calculateServiceFee(destination);
		double expectedCost = chargeInformation.calculateCost(expectedServiceFee, expectedActivityCost);
		double expectedChargeOfItem = chargeInformation.calculateCharge(expectedCost);

		/**Checking to see which pool to place mail item*/
		if (chargeInformation.getChargeThreshold() > 0){
			if (expectedChargeOfItem > chargeInformation.getChargeThreshold()){
				//Place item in Priority Pool
				priorityPool.add(item);
				priorityPool.sort(new ItemComparator());
			}else {
				//Place item in Normal Pool
				normalPool.add(item);
				normalPool.sort(new ItemComparator());
			}
		}else{
			//Place item in Normal Pool
			normalPool.add(item);
			normalPool.sort(new ItemComparator());
		}
	}
	
	
	
	/**
     * load up any waiting robots with mailItems, if any.
     */
	public void loadItemsToRobot() throws ItemTooHeavyException {
		//List available robots
		ListIterator<Robot> i = robots.listIterator();
		while (i.hasNext()) loadItem(i);
	}
	
	/**
	 * Load item to robot from the correct mail pool
	 *
	 * @param i robot from the List Iterator
	 * */
	private void loadItem(ListIterator<Robot> i) throws ItemTooHeavyException {
		Robot robot = i.next();
		assert(robot.isEmpty());
		ListIterator<Item> priorityItem = priorityPool.listIterator();
		ListIterator<Item> normalItem = normalPool.listIterator();

		/**Depending on the size of each pool, place item in robot's hand and tube*/
		if (priorityPool.size() > 0) {
			//There is still mail present in the priority pool, take mail from priority pool
			try {
				robot.addToHand(priorityItem.next().mailItem); // hand first as we want higher priority delivered first
				priorityItem.remove();
				if (priorityPool.size() > 0) {
					robot.addToTube(priorityItem.next().mailItem);
					priorityItem.remove();
				}
				//Priority Pool is empty, take mail from normal pool
				else {
					if (normalPool.size() > 0) {
						robot.addToTube(normalItem.next().mailItem);
						normalItem.remove();
					}
				}
				robot.dispatch(); // send the robot off if it has any items to deliver
				i.remove();       // remove from mailPool queue
			} catch (Exception e) { 
	            throw e; 
	        } 
		} else {
			//Priority Pool is empty, take mail from normal pool
			if (normalPool.size() > 0) {
				try {
					robot.addToHand(normalItem.next().mailItem);
					normalItem.remove();
					if (normalPool.size() > 0) {
						robot.addToTube(normalItem.next().mailItem);
						normalItem.remove();
					}
					robot.dispatch(); // send the robot off if it has any items to deliver
					i.remove();       // remove from mailPool queue
				} catch (Exception e) { 
					throw e; 
		        }
			}
		}
	}

	/**
     * @param robot refers to a robot which has arrived back ready for more mailItems to deliver
     */	
	public void registerWaiting(Robot robot) { // assumes won't be there already
		robots.add(robot);
	}

}
