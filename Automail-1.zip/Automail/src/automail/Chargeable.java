package automail;

/**
 * Created by
 * @author W07 Team 05 [Fri 10:00AM]
 */

/** Contains methods used to calculate charge an cost to tenants */
public interface Chargeable {

    public static final double LOOKUPACTIVITYUNIT = 0.1;

    /**
     * Calculates the charge the tenant is going to pay
     *
     * @param cost The cost the tenant is paying for
     * @return the amount that the tenant is being charged
     * */
    double calculateCharge(double cost) throws Exception;

    /**
     * Calculates the cost the tenant is going to pay based upon the serviceFee and Activity Units
     *
     * @param serviceFee service fee retrieved from the Wifi Modem
     * @param activityCost activity cost calculated for the mail item delivered
     * @return the cost the tenant is paying for
     * */
    double calculateCost(double serviceFee, double activityCost) throws Exception;

    /**
     * Calculates the Activity units based on the destination floor
     *
     * @param destinationFloor the floor where the item is being delivered
     * @return activity units used to calculate the activity cost
     * */
    double calculateActivityUnits(int destinationFloor);

    /**
     * Calculates the Activity Cost based on the work done by the robot
     *
     * @param activityUnits activity units used to calculate the activity cost
     * @return cost for all the activity done
     * */
    double calculateActivityCost(double activityUnits);

    /**
     * Retrieves the service fee from the Wifi Modem
     *
     * @param destinationFloor the floor where the item is being delivered
     * @return The service fee at the moment of time this function is called
     * */
    double calculateServiceFee(int destinationFloor) throws Exception;

    /**
     * Calculates the activity units that the robot is undertaking between the MailRoom location
     * and destination floor of the Mail item
     *
     * @param destinationFloor the floor where the item is being delivered
     * @return The activity units the robot is going to exhaust delivering the items
     * */
    double floorCost(int destinationFloor);
}
