package automail;

/**
 * Created by
 * @author W07 Team 05 [Fri 10:00AM]
 */

/**
 * Class that hold all the statistics of the simulation
 */
public class Statistics {

    private static Statistics statistics = null;

    private int numOfItemsDelivered;
    private double totalBillActivity;
    private double activityCost;
    private double serviceCost;
    private int numOfLookUps;
    private int successfulLookUps;
    private int failedLookUps;

    /**
     * Initiates all the values to 0
     * */
    private Statistics(){
        this.numOfItemsDelivered = 0;
        this.totalBillActivity = 0;
        this.activityCost = 0;
        this.serviceCost = 0;
        this.numOfLookUps = 0;
        this.successfulLookUps = 0;
        this.failedLookUps = 0;
    }

    public static Statistics getInstance(){
        if (statistics == null){
            statistics = new Statistics();
        }
        return statistics;
    }

    /**
     * Increases the number of items delivered in the simulation
     * */
    public void increaseNumOfItemsDelivered(){
        this.numOfItemsDelivered += 1;
    }

    /**
     * Increases the Total Billable Activity in the simulation
     *
     * @param bill activity units performed by the robot
     * */
    public void increaseTotalBillActivity(double bill){
        this.totalBillActivity += bill;
    }

    /**
     * Increases the Total Activity cost in the simulation
     *
     * @param activityCost activity cost calculated when delivering a mail item
     * */
    public void increaseActivityCost(double activityCost){
        this.activityCost += activityCost;
    }

    /**
     * Increases the Total Service fee in the simulation
     *
     * @param serviceCost Service fee retrieved when delivering a mail item
     * */
    public void increaseServiceCost(double serviceCost){
        this.serviceCost += serviceCost;
    }

    /**
     * Increases the Total number of look up of the service fee in the simulation
     * */
    public void increaseNumOfLookUps(){
        this.numOfLookUps += 1;
    }

    /**
     * Increases the Total number of successful look up of the service fee in the simulation
     * */
    public void increaseSuccessfulLookUps(){
        this.successfulLookUps += 1;
    }

    /**
     * Increases the Total number of failed look up of the service fee in the simulation
     * */
    public void increaseFailedLookUps(){
        this.failedLookUps += 1;
    }

    @Override
    public String toString(){
        return String.format("\n\nSimulation Statistics:\n" +
                "Total Number of Items Delivered: %d\nTotal Billable Activity: %.2f\nTotal Activity Cost: %.2f\n" +
                "Total Service Cost: %.2f\nTotal Number of Lookups: %d\nTotal Number of Successful Lookups: %d\n" +
                "Total Number of Failed Lookups: %d\n\n", this.numOfItemsDelivered, this.totalBillActivity,
                this.activityCost, this.serviceCost, this.numOfLookUps, this.successfulLookUps, this.failedLookUps);
    }

    /**
     * Prints all the statistics of the simulation
     * */
    public void printStatistics(){
        System.out.printf("%s",toString());
    }


}
