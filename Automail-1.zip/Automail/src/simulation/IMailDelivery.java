package simulation;

import automail.MailItem;

/**
 * Changes made by
 * @author W07 Team 05 [Fri 10:00AM]
 */

/**
 * a MailDelivery is used by the Robot to deliver mail once it has arrived at the correct location
 */
public interface IMailDelivery {

	/**
     * Delivers an item at its floor
     * @param mailItem the mail item being delivered.
     */
	void deliver(MailItem mailItem);

	/**
	 * Delivers an item at its floor
	 * @param mailItem the mail item being delivered.
	 * @param charge amount charged to client
	 * @param cost cost of delivery
	 * @param fee service fee of delivery
	 * @param activity activity units done by robot for delivery
	 */
	void deliver(MailItem mailItem, double charge, double cost, double fee, double activity);
    
}